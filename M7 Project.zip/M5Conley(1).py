from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections.
        # This is hard-wired to use the aac database, the 
        # animals collection, and the aac user.
        # Definitions of the connection string variables are
        # unique to the individual Apporto environment.
        #
        # You must edit the connection variables below to reflect
        # your own instance of MongoDB!
        #
        # Connection Variables
        #
        # These are the updated credentials needed for my personal access
        # These should be arguments passed to the constructor, not hard-coded.
        # Remove the hardcoded username and password.
        # username = 'aacuser'
        # password = 'SNHU1234'
        # Instead, use the parameters passed to the constructor.
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 30251
        DB = 'AAC'
        COL = 'animals'
        #
        # Initialize Connection
        #
        # Instead of hard-coding the connection string, use the parameters passed to the constructor.
        self.client = MongoClient('mongodb://%s:%s@%s:%d' % (username, password, HOST, PORT))
        self.database = self.client['%s' % (DB)]
        self.collection = self.database['%s' % (COL)]

# Complete this create method to implement the C in CRUD.
    #Input argument to function will be a set of key/value pairs in the data type
    def create(self, data):
        if data is not None:
            self.database.animals.insert_one(data)  # data should be dictionary 
            #Return True is successful
            return True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            #Return False is unsuccessful
            return False

# Create method to implement the R in CRUD.
# Input arguments to function should be the key/value lookup pair to use with the MongoDB driver find API call
    def read(self, search):
        if search is not None:
        #Be sure to use find() instead of find_one() 
        #You must work with the MongoDB cursor returned by the find() method.
            cursor = self.database.animals.find(search)
            # Return result in a list if the command is successful
            result = list(cursor)
            return result
        else:
            raise Exception("Nothing to read, because search parameter is empty")
            #Return an empty list
            return []
        
 #Create method to implement the U in CRUD
    def update(self, search, update_data):
        if search is not None and update_data is not None:
        # The last argument to function will be a set of key/value pairs in the data type acceptable to             the MongoDB driver update_one() or update_many() API call.
        # Find the first instance of search that matches and applies the updated information
        # $set is an update operation to replace specified field with the updated data
            result = self.database.animals.update_one(search, {'$set': update_data})
        # Return the number of objects modified in the collection
            return result.modified_count
        else:
            raise Exception("Invalid input.")
        # Return 0 if no objects were modified
        return 0

# Create method to implement the D in CRUD
    def delete(self, search):
        if search is not None:
        # Use delete_many() to remove all documents that match the search criteria
            result = self.database.animals.delete_one(search)
        # Return the number of objects removed from the collection
            return result.deleted_count
        else:
            raise Exception("Invalid input")
        # Return 0 if no objects were removed
        return 0